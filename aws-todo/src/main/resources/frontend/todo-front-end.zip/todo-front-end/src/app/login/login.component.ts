import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HardcodedAuthenticationService } from '../service/hardcoded-authentication.service';
import { BasicAuthenticationService } from '../service/http/basic-authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username='riyaz'
  password=''
  invalidMessage="Invalid credetial"
  invalidflag=false
  constructor(private basicAuthService:BasicAuthenticationService,private router:Router,private hardcodedAuthenticationService:HardcodedAuthenticationService) { }

  ngOnInit(): void {
  }

  handleBasicLogin()
  {
    this.basicAuthService.executeBasicAuthentication(this.username,this.password)
    .subscribe(
      data=>{
        console.log(data);
        this.router.navigate(['welcome',this.username])
      },
      error=>{
        this.invalidflag=true
      } )
  
  }
  handleLogin()
  {
    if(this.hardcodedAuthenticationService.authenticate(this.username,this.password))
    {
      this.invalidflag=false
      this.router.navigate(['welcome',this.username])
    }
    else{
      this.invalidflag=true
    }
  }

}
