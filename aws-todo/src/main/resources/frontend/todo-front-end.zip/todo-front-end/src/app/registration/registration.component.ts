import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  selectedGender='Male';
  genders=['Male','Female'];
  constructor() { }

  ngOnInit(): void {
  }

  saveRegistrationForm()
  {
    console.log('Hi Arham');
  }

}
