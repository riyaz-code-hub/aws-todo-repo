import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Country } from '../country/country.component';
import { State } from '../state/state.component';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http:HttpClient) { }

  getCountryList()
  {
    return this.http.get<Country[]>("http://localhost:8080/country")
  }

  

  getSateList(counryId)
  {
    return this.http.get<State[]>(`http://localhost:8080/states/country/${counryId}`)
  }

  getDropDownText(id, object){
    const selObj = _.filter(object, function (o) {
        return (_.includes(id,o.countryId));
    });
    return selObj;
  }

  getDropDownSelectedState(id, object){
    const selObj = _.filter(object, function (o) {
        return (_.includes(id,o.stateId));
    });
    return selObj;
  }
}
