import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../employee-list/employee-list.component';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) {  
   }

   getEmployeeData()
   {
    return this.http.get<Employee>('http://localhost:8080/employees');
   }

   saveEmployeeData(employee)
   {
    return this.http.post('http://localhost:8080/employee',employee);
   }

   deleteEmployeeData(empId)
   {
    return this.http.delete(`http://localhost:8080/employee/${empId}`);
   }


}
