import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BasicAuthenticationService } from './basic-authentication.service';

@Injectable({
  providedIn: 'root',
})
export class HttpIntercepterBasicAuthService implements HttpInterceptor {
  constructor(private authService: BasicAuthenticationService) {}
  intercept(request: HttpRequest<any>, next: HttpHandler) {
    // let username='riyaz';
    // let password='pass@123';
    // let basicAuthHeaderString='Basic '+ window.btoa(username+':'+password);

    let basicAuthHeaderString = this.authService.getAuthenticateToken();
    let username = this.authService.getAuthenticateUser();
    if (basicAuthHeaderString && username) {
      request = request.clone({
        setHeaders: {
          Authorization: basicAuthHeaderString,
        },
      });
    }
    return next.handle(request);
  }
}
